# task 2

## Client

```bash
javac -cp ./jeromq.jar task2/hwclient.java && java -cp .:./jeromq.jar task2.hwclient
```

## Server

```bash
javac -cp ./jeromq.jar task2/hwclient.java && java -cp .:./jeromq.jar task2.hwclient
```
