# task 1

## Client

```bash
javac -cp ./jeromq.jar task1/ZClient.java && java -cp .
:./jeromq.jar task1.ZClient
```

## Server

```bash
javac -cp ./jeromq.jar task1/ZServer.java && java -cp .:./jeromq.jar task1.ZServer
```
