# task 4

## Client

```bash
javac -cp ./jeromq.jar task4/wuclient.java && java -cp .:./jeromq.jar task4.wuclient 1004
```

## Server

```bash
javac -cp ./jeromq.jar task4/wuserver.java && java -cp .:./jeromq.jar task4.wuserver
```
