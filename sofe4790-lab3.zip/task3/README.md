# task 3

## Client

```bash
javac -cp ./jeromq.jar task3/hwclient.java && java -cp .:./jeromq.jar task3.hwclient
```

## Server

```bash
javac -cp ./jeromq.jar task3/hwserver.java && java -cp .:./jeromq.jar task3.hwserver
```
